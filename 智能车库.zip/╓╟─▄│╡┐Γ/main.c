#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

#include "head.h"

void usage(int argc, char **argv)
{
	if(argc != 4)
	{
		printf("用法: %s <入库串口> <出库串口> <摄像头设备>\n", argv[0]);
		exit(0);
	}
}


void f(int msg)
{
	system("killall V4L2_demo.elf");
	system("killall RFID_demo.elf");
	system("killall SQLite_demo.elf");
	
	exit(0);
}

int main(int argc, char **argv)   // /dev/ttySAC1  /dev/ttySAC2  /dev/video7
{
	signal(SIGINT, f);
	
	
	usage(argc, argv);

	// 0，创建进程间通信的有名管道
	mkfifo(RFID_SQLite_in,  0777);
	mkfifo(RFID_SQLite_out, 0777);
	mkfifo(SQLite_V4L2, 0777);
	mkfifo(SQLite_ALSA, 0777);
	mkfifo(SQLite_tts_in, 0777);
	mkfifo(SQLite_tts_out, 0777);

	printf("打开各种有名管道\n");
	// 1，启动刷卡程序
	pid_t pid1 = fork();
	if(pid1 == 0)
	{
		execl("./RFID_demo.elf", "./RFID_demo.elf", argv[1], argv[2], NULL);
	}


	// 2，启动数据库程序
	pid_t pid2 = fork();
	if(pid2 == 0)
	{
		execl("./SQLite_demo.elf", "./SQLite_demo.elf", NULL);
	}


	// 3，启动摄像头程序
	pid_t pid3 = fork();
	if(pid3 == 0)
	{
		execl("./V4L2_demo.elf", "./V4L2_demo.elf", argv[3], NULL);
	}

	//4、启动语音引擎程序
	pid_t pid4 = fork();
	if(pid4 == 0)
	{
		execl("./tts","./tts", "192.168.90.210", "50004", NULL);      //开始合合成语音
	}
	
	
	while(1)
		pause();

	return 0;
}
