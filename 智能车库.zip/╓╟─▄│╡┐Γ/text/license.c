﻿#include <time.h>
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <strings.h>
#include <stdbool.h>
#include <pthread.h>
#include <semaphore.h>

#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <linux/fb.h>
#include <linux/un.h>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>

#include "cJSON.h"

int Socket(int domain, int type, int protocol);
int Connect(int sockfd, const struct sockaddr *addr, socklen_t addrlen);
char *http_request(char *no);
int get_size(char *head);


extern int h_errno;

int main(int argc, char **argv)
{
	// 1，取得服务器的IP
	struct hostent *he = gethostbyname("api03.aliyun.venuscn.com");
	if(he == NULL)
	{
		printf("获取服务器IP失败: %s\n", strerror(h_errno));
		exit(0);
	}

	char *ip = inet_ntoa(*((struct in_addr *)(he->h_addr_list[0])));
	printf("%s\n", ip);


	// 2，试图连接服务器
	int sockfd = Socket(AF_INET, SOCK_STREAM, 0);

	struct sockaddr_in addr;
	socklen_t len = sizeof(addr);
	bzero(&addr, len);

	addr.sin_family = AF_INET;
	addr.sin_addr = *((struct in_addr *)(he->h_addr_list[0]));
	addr.sin_port = htons(80);

	Connect(sockfd, (struct sockaddr *)&addr, len);
	printf("============与云端连接成功！=========\n");


	// 3，组织好HTTP的请求报文，并发送给服务器
	printf("=============输入jpg图片二字二进制转符串========:\n");
	
	int fd_a = open("a",O_RDWR);       //打开存放图片字符串数据的文本
	
	char license[30000];
	bzero(license, 30000);
	read(fd_a, license, 30000);
	
	char *req = http_request(license);
	
	printf("===================请求报文:===============\n%s\n", req);

	int len_req = strlen(req);

	int m;
	while(len_req > 0)
	{

		m = write(sockfd, req, strlen(req));
		len_req -= m;
		req += m;
	}
	printf("============发送请求报文成功！===============\n");


	// 4，静静地等待服务器的响应，并判断成功与否

	char response[1024];
	bzero(response, 1024);

	// 4.1 读取响应头部
	for(int i=0; ; i++)
	{
printf("[%d]\n",__LINE__);
		read(sockfd, response+i, 1);
		
		if(strstr(response, "\r\n\r\n"))
			break;
	}
	printf("============响应头部:=================\n%s", response);

	// 4.2 读取JSON
	int len_json = get_size(response);

	printf("=============JSON数据长度:%d============\n", len_json);

	char *json = calloc(1, len_json);
	int total = 0;
	while(len_json > 0)
	{
		int n = read(sockfd, json+total, len_json);
		len_json -= n;
		total += n;
	}
	printf("JSON:\n%s\n", json);

	/*  // 5，分析JSON数据
	cJSON *root = cJSON_Parse(json);
	
	cJSON *data = cJSON_GetObjectItem(root, "data");
	
	char *number = cJSON_GetObjectItem(data, "number")->valuestring;

	printf("车牌号码: %s\n", number);    */

	return 0;
}





int Socket(int domain, int type, int protocol)
{
	int sockfd = socket(domain, type, protocol);
	if(sockfd == -1)
	{
		perror("socket() error");
	}

	return sockfd;
}


int Connect(int sockfd, const struct sockaddr *addr, socklen_t addrlen)
{
	int connfd = connect(sockfd, addr, addrlen);
	if(connfd == -1)
	{
		perror("connect() error");
	}

	return connfd;
}

 char *http_request(char *license)
{
	static char req[40000];
	bzero(req, 40000);

	snprintf(req, 40000, "POST /ocr/car-license?pic=%s HTTP/1.1\r\n"
			   "Host: api03.aliyun.venuscn.com\r\n"
			   "Authorization: APPCODE ef8a566fa2cf4d70acadd2d2c59643ef\r\n\r\n",
			   strtok(license, "\n"));
	return req;
} 

int get_size(char *head)
{
	char *p;
	if((p=strstr(head, "Content-Length:")) != NULL)
	{
		return atoi(p+strlen("Content-Length: "));
	}
}
