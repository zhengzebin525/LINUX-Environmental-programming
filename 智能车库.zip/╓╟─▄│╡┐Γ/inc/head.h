
#ifndef __HEAD_H
#define __HEAD_H

#define RFID_SQLite_in  "/tmp/RFID_SQLite_in"
#define RFID_SQLite_out "/tmp/RFID_SQLite_out"

#define SQLite_V4L2 "/tmp/SQLite_V4L2"
#define SQLite_ALSA "/tmp/SQLite_ALSA"

#define SQLite_tts_in "/tmp/SQLite_tts_in"
#define SQLite_tts_out "/tmp/SQLite_tts_out"


#endif
