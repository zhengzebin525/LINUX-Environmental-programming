#define HAVE_AVX2                  0
#define HAVE_NEON32                0
#define HAVE_NEON64                0
#define HAVE_SSSE3                 0
#define HAVE_SSE41                 0
#define HAVE_SSE42                 0
#define HAVE_AVX                   0
#define HAVE_FAST_UNALIGNED_ACCESS 0
