#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <pthread.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include "common.h"
#include "head.h"
#define WAV "/tmp/a.wav"

int fifo_SQLite_tts_r_in;
int fifo_SQLite_tts_r_out;

void recv_wav(int fd)
{
	// 接受即将到达的音频数据的大小
	char size[10];
	bzero(size, 10);

	read(fd, size, 10);
	long wavsize = atol(size);


	// 接受音频数据
	FILE *fp = fopen(WAV, "w");
	char buf[1024];
	while(wavsize)
	{
		// 读取从Ubuntu发来的音频数据
		bzero(buf, 1024);
		int n = read(fd, buf, 1024);
		if(n <= 0)
			break;

		fwrite(buf, n, 1, fp);
		wavsize -= n;
	}

	fclose(fp);
}

void playback(void)
{
	system("aplay /tmp/a.wav");
}


void *routine(void *msg)
{
	pthread_detach(pthread_self());
	
	int fd = *(int *)msg;
	char buf[200];
	while(1)
	{
		// 3，获取入库语音文本
		bzero(buf, 200);
		read(fifo_SQLite_tts_r_in, buf, 200);
		printf("语音文本：%s\n", buf);

		// 4，将文本发送给语音合成引擎
		Write(fd, buf, strlen(buf));

		// 5，等待返回的语音数据，并播放出来
		recv_wav(fd);
		playback();
	}
	pthread_exit(NULL);
}


int main(int argc, char **argv)
{
	fifo_SQLite_tts_r_in = open(SQLite_tts_in, O_RDWR);
	if(fifo_SQLite_tts_r_in == -1)
	{
		printf("SQLite_demo中入库打开管道失败，不能读取\n");
	}
	
	fifo_SQLite_tts_r_out = open(SQLite_tts_out, O_RDWR);
	if(fifo_SQLite_tts_r_out == -1)
	{
		printf("SQLite_demo中出库打开管道失败，不能读取\n");
	}
	
	
	// 1，准备好TCP套接字，和服务端的地址
	int fd = Socket(AF_INET, SOCK_STREAM, 0);

	struct sockaddr_in addr;
	socklen_t len = sizeof(addr);
	bzero(&addr, len);

	addr.sin_family      = AF_INET;
	addr.sin_addr.s_addr = inet_addr(argv[1]);
	addr.sin_port        = htons(atoi(argv[2]));

	// 2，试图连接Ubuntu上的语音合成引擎
	Connect(fd, (struct sockaddr *)&addr, len);

	pthread_t tid;
	pthread_create(&tid, NULL, routine, (void *)&fd);
	
	char buf[200];
	while(1)
	{
		
		// 3，获取出库语音文本
		bzero(buf, 200);
		read(fifo_SQLite_tts_r_out, buf, 200);
		printf("语音文本：%s\n", buf);

		// 4，将文本发送给语音合成引擎
		Write(fd, buf, strlen(buf));

		// 5，等待返回的语音数据，并播放出来
		recv_wav(fd);
		playback();
	}
	pthread_exit(NULL);
}
